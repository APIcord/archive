# APIcord
## Features
<li><a href="https://coffee.alexflipnote.dev">Coffee Images</a></li>
<li><a href="https://dog.ceo/dog-api">Dog Images</a></li>
<li><a href="https://catfact.ninja">Cat Facts<a/></li>
<li><a href="https://github.com/R3l3ntl3ss/Meme_Api">Reddit Memes</a></li>
<li><a href="https://some-random-api.ml">and more!!!</a></li>

## Ideas
<li>Coronavirus Counter (Maybe)</li>
<li>date</li>

## Instalation
Put you token in the variable "token" in bot.py and run it.
