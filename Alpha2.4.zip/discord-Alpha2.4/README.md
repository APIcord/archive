# APIcord
## Features
<li><a href="https://coffee.alexflipnote.dev">Coffee Images</a></li>
<li><a href="https://dog.ceo/dog-api">Dog Images</a></li>
<li><a href="https://catfact.ninja">Cat Facts<a/></li>
<li><a href="https://github.com/R3l3ntl3ss/Meme_Api">Reddit Memes</a></li>
<li><a href="https://memegen.link">Meme generator</a></li>
<li><a href="https://some-random-api.ml">and more!!!</a></li>

## Ideas
<li>Coronavirus Counter (Maybe)</li>
<li>date</li>

## Instalation
Put you token in the variable "token" in bot.py and run it.

## Official bot
This bot is running in Discord 24/7 in a official "instance", this is disponible from:
<li><a href="https://discordlistology.com/bots/757258298725630008">Discordlistology</a></li>
<li><a href="#">Yet Another Bot List (YABL) [Checking]</a></li>
<li><a href="https://discord.bots.gg/bots/757258298725630008">Discord Bots (bots.gg)</a></li>
<li><a href="#">Bots on Discord [Checking]</a></li>
<li><a href="https://top.gg/bot/757258298725630008">Discord Bot List / Top.gg / DBL</a></li>
<li><a href="https://apicord.github.io/invite">Here</a></li>
