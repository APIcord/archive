# [API](https://en.wikipedia.org/wiki/API)[cord](https://en.wikipedia.org/wiki/Discord_(software)) Discord [![Run on Repl.it](https://repl.it/badge/github/APIcord/discord)](https://repl.it/github/APIcord/discord)
## Features
- [Coffee Images](https://coffee.alexflipnote.dev)
- [Dog Images](https://dog.ceo/dog-api)
- [Cat Facts](https://catfact.ninja)
- [Reddit Memes](https://github.com/R3l3ntl3ss/Meme_Api)
- [Meme generator](https://memegen.link)
- [and more!!!](https://some-random-api.ml)

## Ideas
- Coronavirus Counter (Maybe)
- date

## Instalation
Put you token in the variable "token" in bot.py and run it.

## Official bot
This bot is running in Discord 24/7 in a official "instance", this is disponible from:
- [Discordlistology](https://discordlistology.com/bots/757258298725630008)
- [Discord Bots (bots.gg)](https://discord.bots.gg/bots/757258298725630008)
- [Discord Bot List / Top.gg / DBL](https://top.gg/bot/757258298725630008)
- [Here](https://apicord.github.io/invite)
