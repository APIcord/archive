pip install -r requirements.txt
python bot.py
