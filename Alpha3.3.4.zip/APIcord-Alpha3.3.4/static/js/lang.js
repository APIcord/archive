var theLang = navigator.language || navigator.userLanguage;
var isSpanish;
if (theLang=="es") {
    /* Spanish */
    isSpanish = true;
} else if (theLang=="es-419") {
    isSpanish = true;
} else if (theLang=="es-AR") {
    isSpanish = true;
} else if (theLang=="es-BO") {
    isSpanish = true;
} else if (theLang=="es-CL") {
    isSpanish = true;
} else if (theLang=="es-CO") {
    isSpanish = true;
} else if (theLang=="es-CR") {
    isSpanish = true;
} else if (theLang=="es-DO") {
    isSpanish = true;
} else if (theLang=="es-EC") {
    isSpanish = true;
} else if (theLang=="es-ES") {
    isSpanish = true;
} else if (theLang=="es-GT") {
    isSpanish = true;
} else if (theLang=="es-HN") {
    isSpanish = true;
} else if (theLang=="es-MX") {
    isSpanish = true;
} else if (theLang=="es-NI") {
    isSpanish = true;
} else if (theLang=="es-PA") {
    isSpanish = true;
} else if (theLang=="es-PE") {
    isSpanish = true;
} else if (theLang=="es-PR") {
    isSpanish = true;
} else if (theLang=="es-PY") {
    isSpanish = true;
} else if (theLang=="es-SV") {
    isSpanish = true;
} else if (theLang=="es-UY") {
    isSpanish = true;
} else if (theLang=="es-VE") {
    isSpanish = true;
} else {
    isSpanish = false;
}