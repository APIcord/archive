# APIcord
## Features
<li><a href="https://coffee.alexflipnote.dev">Coffee Images</a></li>
<li><a href="https://dog.ceo/dog-api">Dog Images</a></li>
<li><a href="https://catfact.ninja">Cat Facts<a/></li>
<li><a href="https://github.com/R3l3ntl3ss/Meme_Api">Reddit Memes</a></li>
<li><a href="https://some-random-api.ml">and more!!!</a></li>

## Ideas
<li>Coronavirus Counter (Maybe)</li>
<li>date</li>

## Instalation
Put you token in the variable "token" in bot.py and run it.

## Official bot
This bot is running in Discord 24/7 in a official "instance", this is disponible from:
<li><a href="https://discordextremelist.xyz/es-ES/bots/757258298725630008">Discord Extreme List (DEL) [Checking]</a></li>
<li><a href="https://yabl.xyz/bot/757258298725630008">Yet Another Bot List (YABL)</a></li>
<li><a href="https://discord.bots.gg/bots/757258298725630008">bots.gg [Checking]</a></li>
<li><a href="https://bots.ondiscord.xyz/bots/757258298725630008">Bots on Discord [Checking]</a></li>
<li><a href="https://top.gg/bot/757258298725630008">Top.gg [Checking]</a></li>
